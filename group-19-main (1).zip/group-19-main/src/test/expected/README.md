# Expected 

This folder contains expected outputs from running the tests. 
If any of these files changes something has happened.

See `TestUtils.goldenTest(name, image)` for more.