package dtu.compute.pixels.controller;

public interface Observer {

  void onChange();

}
