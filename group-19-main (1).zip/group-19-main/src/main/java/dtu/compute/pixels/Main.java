package dtu.compute.pixels;

import dtu.compute.pixels.view.Pixels;

public class Main {
    public static void main(String[] args) {
        Pixels.main(args);
    }
}